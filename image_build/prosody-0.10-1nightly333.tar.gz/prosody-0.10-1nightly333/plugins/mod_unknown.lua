-- Unknown platform stub
module:set_global();

-- TODO Do things that make sense if we don't know about the platform
